a,b = raw_input('Insert A & B -> ').split()
print((int(a)+int(b)))

# Python 3.4
code_abbey_wasted_variable = input()
print(sum(int(x) for x in input().split()))

# Python 3.4
print(input()[::-1])

# Python 2.7
print(raw_input()[::-1])
